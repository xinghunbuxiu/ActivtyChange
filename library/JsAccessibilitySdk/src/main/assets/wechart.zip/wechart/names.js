var sendText = '叫我哥哥';

var names = [
	'aaaa',
	'bbbb',
	'cccc',
	'dddd',
]

function getNames() {
	return names;
}
function getSendText() {
	return sendText;
}
