package com.lixh.jsSdk.jsevaluator.interfaces;

public interface HandlerWrapperInterface {
	public void post(Runnable r);
}
