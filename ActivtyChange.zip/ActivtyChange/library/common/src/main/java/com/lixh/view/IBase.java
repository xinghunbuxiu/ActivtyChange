package com.lixh.view;

import android.app.Activity;

/**
 * Created by LIXH on 2017/5/17.
 * email lixhVip9@163.com
 * des
 */

public interface IBase<M> {

    void setData(M bean);
}
