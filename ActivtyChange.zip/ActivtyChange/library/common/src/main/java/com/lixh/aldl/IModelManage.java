package com.lixh.aldl;

/**
 * Created by Administrator on 2016/10/21.
 */

public interface IModelManage {

}
