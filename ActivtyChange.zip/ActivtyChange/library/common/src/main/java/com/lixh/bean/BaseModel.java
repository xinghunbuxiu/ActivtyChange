package com.lixh.bean;

import java.io.Serializable;

/**
 * Created by Administrator on 2016/10/25.
 */
public class BaseModel implements Serializable {

}
