package com.lixh.rxhttp.exception;


public class ServerException extends Exception {

    public ServerException(String msg) {
        super(msg);
    }

}