package com.lixh.rxlife;

public enum LifeEvent {
    DESTROY,
    ATTACH,
    CREATE,
    CREATE_VIEW,
    START,
    RESUME,
    PAUSE,
    STOP,
    DESTORY_VIEW,
    DESTORY,
    DETACH,
}