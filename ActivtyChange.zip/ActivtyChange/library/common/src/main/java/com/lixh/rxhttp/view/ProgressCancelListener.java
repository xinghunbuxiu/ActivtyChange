package com.lixh.rxhttp.view;

/**
 * Created by helin on 2016/10/10 15:50.
 */

public interface ProgressCancelListener {
    void onCancelProgress();
}
