package com.yhao.floatwindow;

/**
 * Created by yhao on 2017/12/30.
 * https://github.com/yhaolpz
 */

interface ResumedListener {
    void onResumed();
}
