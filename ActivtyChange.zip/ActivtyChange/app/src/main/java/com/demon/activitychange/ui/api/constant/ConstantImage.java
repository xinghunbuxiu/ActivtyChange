package com.demon.activitychange.ui.api.constant;

public class ConstantImage {


    public static String[] homePageConcentration = {
        "http://sandcolleges.zero2ipo.com.cn/vc-talk-img/1513594514204.png",
        "http://sandcolleges.zero2ipo.com.cn/vc-talk-img/1514968425896.png",
        "http://sandcolleges.zero2ipo.com.cn/vc-talk-img/1513595685864.png",
        "http://sandcolleges.zero2ipo.com.cn/vc-talk-img/1513596366962.png",
    };


}
