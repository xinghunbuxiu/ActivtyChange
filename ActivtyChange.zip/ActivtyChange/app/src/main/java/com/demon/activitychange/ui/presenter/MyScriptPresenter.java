package com.demon.activitychange.ui.presenter;

import android.os.Bundle;

import com.demon.activitychange.ui.fragment.MyScriptFragment;
import com.lixh.presenter.BasePresenter;

/**
 * Created by LIXH on 2018/11/16.
 * email lixhVip9@163.com
 * des
 */

public class MyScriptPresenter extends BasePresenter<MyScriptFragment> {

    @Override
    public void onCreate(Bundle savedInstanceState) {
    }

}
