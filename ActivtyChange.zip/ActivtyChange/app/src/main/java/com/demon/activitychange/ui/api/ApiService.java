package com.demon.activitychange.ui.api;


/**
 * Created by helin on 2016/10/9 17:09.
 */

public interface ApiService {

}
