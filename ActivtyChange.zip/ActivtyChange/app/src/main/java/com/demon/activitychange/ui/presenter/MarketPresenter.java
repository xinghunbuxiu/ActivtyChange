package com.demon.activitychange.ui.presenter;

import android.os.Bundle;

import com.demon.activitychange.ui.fragment.MarketFragment;
import com.lixh.presenter.BasePresenter;


/**
 * Created by LIXH on 2016/11/14.
 * email lixhVip9@163.com
 * des
 */
public class MarketPresenter extends BasePresenter<MarketFragment> {

    @Override
    public void onCreate(Bundle savedInstanceState) {

    }

    public void getScriptList() {

    }
}
