package com.demon.activitychange.ui.api.constant;

/**
 * Description:
 * Update:
 * CreatedTime:2018/01/03
 * Author:yc
 */

public class Constant {


    public static String BOOK_CACHE_FOLDER = "/book_cache";
    public static String BOOK_CACHE_PATH = null;

}
