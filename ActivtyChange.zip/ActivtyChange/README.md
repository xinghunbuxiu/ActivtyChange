Android使用AccessibilityService监听用户操作
原文链接<https://blog.csdn.net/DeMonliuhui/article/details/81634566>